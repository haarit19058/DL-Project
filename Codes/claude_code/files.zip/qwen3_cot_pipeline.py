#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Qwen 3 4B End-to-End Training Pipeline with CoT
================================================
Step 1: SFT on CodeForces CoT dataset
Step 2: GRPO reinforcement learning
Step 3: Benchmarking & Evaluation
Step 4: Inference-time training (context distillation)

Author: Enhanced Pipeline
Date: 2024
"""

import os
import re
import sys
import json
import tempfile
import subprocess
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from collections import defaultdict
import numpy as np

# ==========================================
# INSTALLATION & SETUP
# ==========================================
def install_dependencies():
    """Install required packages"""
    packages = [
        "unsloth",
        "trl==0.24.0",
        "datasets",
        "transformers==5.5.0",
        "bitsandbytes",
        "accelerate",
        "vllm",
        "huggingface_hub",
        "mergekit",
        "flashinfer-cubin==0.6.4",
        "wandb",  # For experiment tracking
        "nltk",   # For advanced text analysis
    ]
    
    for package in packages:
        os.system(f"pip install {package}")

# Uncomment to install dependencies
# install_dependencies()

# ==========================================
# IMPORTS
# ==========================================
from unsloth import FastLanguageModel, is_bfloat16_supported
import torch
from datasets import load_dataset, Dataset
from trl import SFTTrainer, GRPOConfig, GRPOTrainer
from transformers import TrainingArguments, TrainerCallback
from transformers.utils import logging
from itertools import islice
from pprint import pprint

# Suppress overly verbose warnings
logging.set_verbosity_info()

# ==========================================
# CONFIGURATION
# ==========================================
@dataclass
class PipelineConfig:
    """Centralized configuration for the entire pipeline"""
    
    # Model configuration
    model_name: str = "unsloth/Qwen3-4B-unsloth-bnb-4bit"
    max_seq_length: int = 4096  # Increased for longer CoT reasoning
    load_in_4bit: bool = True
    
    # LoRA configuration (stable settings)
    lora_r: int = 32  # Increased for better capacity
    lora_alpha: int = 64  # 2x r for stable training
    lora_dropout: float = 0.05  # Small dropout for regularization
    
    # SFT configuration
    sft_train_samples: int = 5000
    sft_eval_samples: int = 500
    sft_epochs: int = 2
    sft_batch_size: int = 2
    sft_grad_accum: int = 8  # Effective batch = 16
    sft_learning_rate: float = 2e-4
    sft_warmup_ratio: float = 0.1
    
    # GRPO configuration
    grpo_train_samples: int = 2000
    grpo_epochs: int = 3
    grpo_batch_size: int = 1
    grpo_grad_accum: int = 8
    grpo_learning_rate: float = 5e-6
    grpo_num_generations: int = 4
    grpo_max_completion_length: int = 2048
    
    # Dataset configuration
    dataset_name: str = "open-r1/codeforces-cots"
    dataset_subset: str = "solutions_py_decontaminated"
    problem_filter: str = "A"  # Start with easier problems
    
    # Paths
    sft_output_dir: str = "outputs/sft_cot"
    grpo_output_dir: str = "outputs/grpo_cot"
    final_model_dir: str = "outputs/final_model"
    benchmark_dir: str = "outputs/benchmarks"
    
    # Misc
    seed: int = 3407
    report_to: str = "none"  # Change to "wandb" for tracking

config = PipelineConfig()

# ==========================================
# STEP 1: SFT WITH COT DATASET
# ==========================================

class SFTCoTPipeline:
    """Supervised Fine-Tuning with Chain-of-Thought data"""
    
    def __init__(self, config: PipelineConfig):
        self.config = config
        self.model = None
        self.tokenizer = None
        
    def load_model(self):
        """Load base model with LoRA configuration"""
        print("="*50)
        print("STEP 1: Loading Model for SFT")
        print("="*50)
        
        self.model, self.tokenizer = FastLanguageModel.from_pretrained(
            model_name=self.config.model_name,
            max_seq_length=self.config.max_seq_length,
            load_in_4bit=self.config.load_in_4bit,
            fast_inference=False,
        )
        
        # Set pad token
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Apply LoRA
        self.model = FastLanguageModel.get_peft_model(
            self.model,
            r=self.config.lora_r,
            lora_alpha=self.config.lora_alpha,
            lora_dropout=self.config.lora_dropout,
            bias="none",
            use_gradient_checkpointing="unsloth",
            random_state=self.config.seed,
            use_rslora=True,  # Rank-stabilized LoRA
            target_modules=[
                "q_proj", "k_proj", "v_proj", "o_proj",
                "gate_proj", "up_proj", "down_proj"
            ]
        )
        
        print(f"✓ Model loaded: {self.config.model_name}")
        print(f"✓ LoRA Config: r={self.config.lora_r}, alpha={self.config.lora_alpha}")
        
    def prepare_sft_dataset(self):
        """
        Prepare CoT dataset for SFT with proper formatting
        
        CRITICAL: The dataset has 'messages' field pre-formatted for chat.
        We need to convert this to proper text format with CoT structure.
        """
        print("\n" + "="*50)
        print("Preparing SFT Dataset")
        print("="*50)
        
        # Stream dataset efficiently
        ds_stream = load_dataset(
            self.config.dataset_name,
            name=self.config.dataset_subset,
            split="train",
            streaming=True
        )
        
        # Filter for target problem type
        filtered_stream = ds_stream.filter(
            lambda x: x['id'].endswith(self.config.problem_filter)
        )
        
        # Take samples
        total_samples = self.config.sft_train_samples + self.config.sft_eval_samples
        data_list = list(islice(filtered_stream, total_samples))
        
        print(f"✓ Loaded {len(data_list)} total samples")
        
        # Format the dataset properly for CoT learning
        formatted_data = []
        for item in data_list:
            formatted_item = self._format_cot_example(item)
            if formatted_item:
                formatted_data.append(formatted_item)
        
        # Convert to Dataset and split
        dataset = Dataset.from_list(formatted_data)
        split = dataset.train_test_split(
            test_size=self.config.sft_eval_samples / len(formatted_data),
            seed=self.config.seed
        )
        
        train_dataset = split['train']
        eval_dataset = split['test']
        
        print(f"✓ Train samples: {len(train_dataset)}")
        print(f"✓ Eval samples: {len(eval_dataset)}")
        
        # Show example
        print("\n--- Example Training Sample ---")
        pprint(train_dataset[0]['text'][:500] + "...")
        
        return train_dataset, eval_dataset
    
    def _format_cot_example(self, item: Dict) -> Optional[Dict]:
        """
        Format a single example with proper CoT structure
        
        The 'messages' field contains:
        - System message
        - User message (problem statement)
        - Assistant message (CoT reasoning + solution)
        """
        try:
            messages = item.get('messages', [])
            if len(messages) < 2:
                return None
            
            # Extract components
            system_msg = ""
            user_msg = ""
            assistant_msg = ""
            
            for msg in messages:
                role = msg.get('role', '')
                content = msg.get('content', '')
                
                if role == 'system':
                    system_msg = content
                elif role == 'user':
                    user_msg = content
                elif role == 'assistant':
                    assistant_msg = content
            
            # Create formatted text with explicit CoT structure
            # This helps the model learn the thinking pattern
            formatted_text = f"""<|im_start|>system
{system_msg if system_msg else "You are an expert competitive programmer. Think step-by-step and explain your reasoning before providing the solution."}
<|im_end|>
<|im_start|>user
{user_msg}

Please think through this problem step-by-step inside <think></think> tags, then provide your solution in a code block.
<|im_end|>
<|im_start|>assistant
{assistant_msg}
<|im_end|>"""
            
            return {
                'text': formatted_text,
                'id': item.get('id', 'unknown'),
                'messages': messages  # Keep original for reference
            }
            
        except Exception as e:
            print(f"Warning: Failed to format example: {e}")
            return None
    
    def train_sft(self, train_dataset, eval_dataset):
        """Execute SFT training with stable parameters"""
        print("\n" + "="*50)
        print("Starting SFT Training")
        print("="*50)
        
        training_args = TrainingArguments(
            # Core training params
            per_device_train_batch_size=self.config.sft_batch_size,
            per_device_eval_batch_size=self.config.sft_batch_size,
            gradient_accumulation_steps=self.config.sft_grad_accum,
            num_train_epochs=self.config.sft_epochs,
            
            # Learning rate & scheduler
            learning_rate=self.config.sft_learning_rate,
            warmup_ratio=self.config.sft_warmup_ratio,
            lr_scheduler_type="cosine",
            
            # Optimization
            optim="adamw_8bit",
            weight_decay=0.01,
            max_grad_norm=1.0,  # Gradient clipping for stability
            
            # Precision
            fp16=not is_bfloat16_supported(),
            bf16=is_bfloat16_supported(),
            
            # Evaluation & Logging
            eval_strategy="steps",
            eval_steps=100,
            logging_steps=25,
            save_strategy="steps",
            save_steps=200,
            save_total_limit=3,
            load_best_model_at_end=True,
            metric_for_best_model="eval_loss",
            
            # Output
            output_dir=self.config.sft_output_dir,
            report_to=self.config.report_to,
            seed=self.config.seed,
        )
        
        trainer = SFTTrainer(
            model=self.model,
            tokenizer=self.tokenizer,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            dataset_text_field="text",
            max_seq_length=self.config.max_seq_length,
            dataset_num_proc=os.cpu_count() or 4,
            packing=False,  # Don't pack for clearer eval
            args=training_args,
        )
        
        # Train
        print("\n🚀 Starting training...")
        trainer_stats = trainer.train()
        
        # Save
        print("\n💾 Saving SFT model...")
        self.model.save_pretrained(self.config.sft_output_dir + "/final")
        self.tokenizer.save_pretrained(self.config.sft_output_dir + "/final")
        
        print("✓ SFT Training Complete!")
        return trainer_stats

# ==========================================
# STEP 2: GRPO TRAINING WITH ENHANCED REWARDS
# ==========================================

class EnhancedRewardFunctions:
    """
    Sophisticated reward functions for GRPO training
    Rewards: Format, Correctness, Reasoning Quality, Code Quality
    """
    
    @staticmethod
    def format_reward(completions, **kwargs) -> List[float]:
        """
        Reward for proper format: <think>...</think> + code block
        
        Returns: 0.0 to 1.0
        """
        rewards = []
        for comp in completions:
            content = comp[0]['content'] if isinstance(comp, list) else comp
            
            score = 0.0
            
            # Check for think tags (0.3 points)
            has_think_open = bool(re.search(r"<think>", content))
            has_think_close = bool(re.search(r"</think>", content))
            if has_think_open and has_think_close:
                score += 0.3
            elif has_think_open or has_think_close:
                score += 0.1  # Partial credit
            
            # Check for code block (0.3 points)
            has_code = bool(re.search(r"```(python|cpp)\n.*?```", content, re.DOTALL))
            if has_code:
                score += 0.3
            
            # Check for proper ordering: think before code (0.2 points)
            think_match = re.search(r"<think>(.*?)</think>", content, re.DOTALL)
            code_match = re.search(r"```(python|cpp)\n(.*?)```", content, re.DOTALL)
            if think_match and code_match:
                if content.index(think_match.group(0)) < content.index(code_match.group(0)):
                    score += 0.2
            
            # Check for complete response (0.2 points)
            if len(content.strip()) > 100:  # Minimum reasonable length
                score += 0.2
            
            rewards.append(score)
        
        return rewards
    
    @staticmethod
    def reasoning_quality_reward(completions, **kwargs) -> List[float]:
        """
        Reward for quality of reasoning in <think> tags
        
        Evaluates:
        - Length and detail of reasoning
        - Use of logical connectives
        - Step-by-step breakdown
        - Edge case consideration
        
        Returns: -0.5 to 1.0
        """
        rewards = []
        
        for comp in completions:
            content = comp[0]['content'] if isinstance(comp, list) else comp
            
            # Extract thinking content
            think_match = re.search(r"<think>(.*?)</think>", content, re.DOTALL)
            if not think_match:
                rewards.append(-0.2)  # Penalty for no reasoning
                continue
            
            thinking = think_match.group(1).strip()
            score = 0.0
            
            # 1. Length-based reward (0.0 to 0.3)
            # Encourage detailed reasoning but penalize excessive verbosity
            word_count = len(thinking.split())
            if word_count < 20:
                score += 0.0
            elif word_count < 50:
                score += 0.1
            elif word_count < 150:
                score += 0.2 + 0.1 * min((word_count - 50) / 100, 1.0)
            elif word_count < 300:
                score += 0.3
            else:
                score += 0.2  # Slight penalty for extreme verbosity
            
            # 2. Logical structure (0.0 to 0.3)
            logical_indicators = [
                r'\b(first|second|third|then|next|finally)\b',  # Step indicators
                r'\b(because|since|therefore|thus|hence)\b',     # Causal
                r'\b(if|when|while|for each)\b',                 # Conditionals
                r'\b(consider|note|observe|notice)\b',           # Analytical
            ]
            logic_score = 0.0
            for pattern in logical_indicators:
                matches = len(re.findall(pattern, thinking, re.IGNORECASE))
                logic_score += min(matches * 0.05, 0.075)  # Cap per category
            score += min(logic_score, 0.3)
            
            # 3. Mathematical/algorithmic thinking (0.0 to 0.2)
            algo_indicators = [
                r'\b(time complexity|space complexity|O\(.*?\))\b',
                r'\b(algorithm|approach|strategy|method)\b',
                r'\b(edge case|corner case|boundary)\b',
                r'\b(optimize|efficient|improve)\b',
            ]
            algo_score = 0.0
            for pattern in algo_indicators:
                if re.search(pattern, thinking, re.IGNORECASE):
                    algo_score += 0.05
            score += min(algo_score, 0.2)
            
            # 4. Structured thinking (0.0 to 0.2)
            # Bullet points, numbered lists, or clear paragraphs
            has_bullets = bool(re.search(r'^\s*[-*•]\s', thinking, re.MULTILINE))
            has_numbers = bool(re.search(r'^\s*\d+[\.)]\s', thinking, re.MULTILINE))
            has_paragraphs = len(thinking.split('\n\n')) > 1
            
            if has_bullets or has_numbers:
                score += 0.15
            elif has_paragraphs:
                score += 0.1
            
            rewards.append(min(score, 1.0))
        
        return rewards
    
    @staticmethod
    def extract_code(completion: str) -> Tuple[Optional[str], Optional[str]]:
        """Extract language and code from completion"""
        match = re.search(r"```(python|cpp)\n(.*?)```", completion, re.DOTALL)
        if match:
            return match.group(1), match.group(2).strip()
        return None, None
    
    @staticmethod
    def code_quality_reward(completions, **kwargs) -> List[float]:
        """
        Reward for code quality (static analysis)
        
        Evaluates:
        - Proper structure and syntax
        - Use of functions/modularization
        - Comments and readability
        - Pythonic patterns
        
        Returns: 0.0 to 0.5
        """
        rewards = []
        
        for comp in completions:
            content = comp[0]['content'] if isinstance(comp, list) else comp
            lang, code = EnhancedRewardFunctions.extract_code(content)
            
            if not code:
                rewards.append(0.0)
                continue
            
            score = 0.0
            
            # Only evaluate Python for now
            if lang == "python":
                # 1. Function definition (0.1 points)
                if re.search(r'\bdef\s+\w+\s*\(', code):
                    score += 0.1
                
                # 2. Comments or docstrings (0.1 points)
                has_comments = bool(re.search(r'#.*$', code, re.MULTILINE))
                has_docstring = bool(re.search(r'""".*?"""', code, re.DOTALL))
                if has_comments or has_docstring:
                    score += 0.1
                
                # 3. Good variable names (0.1 points)
                # Check for descriptive names (not just x, y, i, j)
                var_names = re.findall(r'\b([a-z_][a-z0-9_]{2,})\b', code)
                if len(set(var_names)) >= 3:
                    score += 0.1
                
                # 4. Use of comprehensions or generators (0.1 points)
                if re.search(r'\[.*for.*in.*\]|\(.*for.*in.*\)', code):
                    score += 0.05
                
                # 5. Reasonable length (0.1 points)
                # Not too short (< 5 lines) or too long (> 100 lines)
                lines = [l for l in code.split('\n') if l.strip()]
                if 5 <= len(lines) <= 100:
                    score += 0.1
            
            rewards.append(min(score, 0.5))
        
        return rewards
    
    @staticmethod
    def correctness_reward(completions, input_tests, output_tests, **kwargs) -> List[float]:
        """
        Reward for correctness by executing code against test cases
        
        Returns: -2.0 to 3.0
        - Compilation failure: -2.0
        - All tests pass: 3.0
        - Majority pass: 0.5 to 2.0 (scaled)
        - Minority pass: -0.5
        """
        rewards = []
        
        for comp, inputs, outputs in zip(completions, input_tests, output_tests):
            content = comp[0]['content'] if isinstance(comp, list) else comp
            lang, code = EnhancedRewardFunctions.extract_code(content)
            
            if not code or not lang:
                rewards.append(-1.0)
                continue
            
            # Execute tests
            score = 0
            total = len(inputs)
            compilation_failed = False
            
            for test_input, expected_output in zip(inputs, outputs):
                try:
                    with tempfile.NamedTemporaryFile(
                        mode='w',
                        suffix='.py' if lang == 'python' else '.cpp',
                        delete=False
                    ) as tmp:
                        tmp.write(code)
                        tmp_path = tmp.name
                    
                    try:
                        if lang == 'python':
                            # Run Python
                            result = subprocess.run(
                                ['python3', tmp_path],
                                input=test_input,
                                capture_output=True,
                                text=True,
                                timeout=5
                            )
                        else:
                            # Compile C++
                            exe_path = tmp_path + '.out'
                            compile_result = subprocess.run(
                                ['g++', '-std=c++17', tmp_path, '-o', exe_path],
                                capture_output=True,
                                text=True,
                                timeout=10
                            )
                            
                            if compile_result.returncode != 0:
                                compilation_failed = True
                                break
                            
                            # Run C++
                            result = subprocess.run(
                                [exe_path],
                                input=test_input,
                                capture_output=True,
                                text=True,
                                timeout=5
                            )
                            os.remove(exe_path)
                        
                        # Check output
                        actual_output = result.stdout.strip()
                        expected_output = str(expected_output).strip()
                        
                        if actual_output == expected_output:
                            score += 1
                    
                    finally:
                        os.remove(tmp_path)
                
                except subprocess.TimeoutExpired:
                    pass  # Timeout = failed test
                except Exception:
                    pass  # Any other error = failed test
            
            # Compute reward based on performance
            if compilation_failed:
                rewards.append(-2.0)
            elif score == total and total > 0:
                rewards.append(3.0)  # Perfect score!
            elif score > total / 2:
                # Partial success: scale from 0.5 to 2.5
                partial_reward = 0.5 + 2.0 * (score / total)
                rewards.append(partial_reward)
            else:
                rewards.append(-0.5)
        
        return rewards

class GRPOPipeline:
    """GRPO training with enhanced reward functions"""
    
    def __init__(self, config: PipelineConfig, model, tokenizer):
        self.config = config
        self.model = model
        self.tokenizer = tokenizer
        self.rewards = EnhancedRewardFunctions()
    
    def prepare_grpo_dataset(self):
        """Prepare dataset for GRPO training"""
        print("\n" + "="*50)
        print("STEP 2: Preparing GRPO Dataset")
        print("="*50)
        
        # Load dataset
        dataset = load_dataset(
            self.config.dataset_name,
            name=self.config.dataset_subset,
            split=f"train[:{self.config.grpo_train_samples}]"
        )
        
        # Filter for target problems
        filtered = dataset.filter(
            lambda x: x['id'].endswith(self.config.problem_filter)
        )
        
        # Format for GRPO
        processed = filtered.map(
            self._format_grpo_example,
            num_proc=os.cpu_count() or 4
        )
        
        print(f"✓ GRPO training samples: {len(processed)}")
        
        # Show example
        print("\n--- Example GRPO Prompt ---")
        print(processed[0]['prompt'][:300] + "...")
        
        return processed
    
    def _format_grpo_example(self, row: Dict) -> Dict:
        """Format example for GRPO"""
        # Extract test cases
        examples = row.get('examples', [])
        input_tests = [str(ex['input']) for ex in examples]
        output_tests = [str(ex['output']) for ex in examples]
        
        # Create prompt that enforces CoT format
        prompt = (
            "You are a competitive programming expert. "
            "Think step-by-step inside <think></think> tags, "
            "then provide your solution in a code block.\n\n"
            f"{row['prompt']}\n\n"
            "<think>\n"
        )
        
        return {
            "prompt": prompt,
            "input_tests": input_tests,
            "output_tests": output_tests,
            "id": row.get('id', 'unknown')
        }
    
    def train_grpo(self, train_dataset):
        """Execute GRPO training"""
        print("\n" + "="*50)
        print("Starting GRPO Training")
        print("="*50)
        
        # Configure GRPO
        training_args = GRPOConfig(
            # Learning
            learning_rate=self.config.grpo_learning_rate,
            per_device_train_batch_size=self.config.grpo_batch_size,
            gradient_accumulation_steps=self.config.grpo_grad_accum,
            num_train_epochs=self.config.grpo_epochs,
            
            # Generation
            num_generations=self.config.grpo_num_generations,
            max_completion_length=self.config.grpo_max_completion_length,
            
            # RL specifics
            loss_type="grpo",
            importance_sampling_level="sequence",
            
            # Regularization
            lr_scheduler_type="cosine",
            weight_decay=0.1,
            max_grad_norm=1.0,
            
            # Logging & Saving
            logging_steps=10,
            save_strategy="steps",
            save_steps=50,
            save_total_limit=3,
            
            # Output
            output_dir=self.config.grpo_output_dir,
            report_to=self.config.report_to,
        )
        
        # Create trainer with enhanced rewards
        trainer = GRPOTrainer(
            model=self.model,
            args=training_args,
            processing_class=self.tokenizer,
            reward_funcs=[
                self.rewards.format_reward,
                self.rewards.reasoning_quality_reward,
                self.rewards.code_quality_reward,
                self.rewards.correctness_reward,
            ],
            train_dataset=train_dataset,
        )
        
        print("\n🚀 Starting GRPO training...")
        trainer.train()
        
        # Save final model
        print("\n💾 Saving GRPO model...")
        trainer.save_model(self.config.grpo_output_dir + "/final")
        self.tokenizer.save_pretrained(self.config.grpo_output_dir + "/final")
        
        print("✓ GRPO Training Complete!")

# ==========================================
# STEP 3: BENCHMARKING & EVALUATION
# ==========================================

class BenchmarkPipeline:
    """Comprehensive evaluation suite"""
    
    def __init__(self, model, tokenizer, config: PipelineConfig):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.rewards = EnhancedRewardFunctions()
    
    def run_benchmark(self, test_dataset, num_samples: int = 100):
        """Run comprehensive benchmark evaluation"""
        print("\n" + "="*50)
        print("STEP 3: Running Benchmark Evaluation")
        print("="*50)
        
        results = {
            'format_scores': [],
            'reasoning_scores': [],
            'code_quality_scores': [],
            'correctness_scores': [],
            'all_tests_passed': 0,
            'compilation_failures': 0,
            'total_evaluated': 0,
        }
        
        # Evaluate samples
        for i in range(min(num_samples, len(test_dataset))):
            sample = test_dataset[i]
            
            # Generate solution
            prompt = self._create_eval_prompt(sample)
            completion = self._generate_solution(prompt)
            
            # Compute all reward metrics
            format_score = self.rewards.format_reward([completion])[0]
            reasoning_score = self.rewards.reasoning_quality_reward([completion])[0]
            code_quality_score = self.rewards.code_quality_reward([completion])[0]
            correctness_score = self.rewards.correctness_reward(
                [completion],
                [sample['input_tests']],
                [sample['output_tests']]
            )[0]
            
            # Store results
            results['format_scores'].append(format_score)
            results['reasoning_scores'].append(reasoning_score)
            results['code_quality_scores'].append(code_quality_score)
            results['correctness_scores'].append(correctness_score)
            
            if correctness_score >= 2.5:  # All tests passed
                results['all_tests_passed'] += 1
            elif correctness_score == -2.0:  # Compilation failure
                results['compilation_failures'] += 1
            
            results['total_evaluated'] += 1
            
            # Progress
            if (i + 1) % 10 == 0:
                print(f"Evaluated {i + 1}/{num_samples} samples...")
        
        # Compute statistics
        stats = self._compute_statistics(results)
        
        # Save results
        self._save_benchmark_results(stats)
        
        # Print summary
        self._print_benchmark_summary(stats)
        
        return stats
    
    def _create_eval_prompt(self, sample: Dict) -> str:
        """Create evaluation prompt"""
        return (
            "Think step-by-step inside <think></think> tags, "
            "then provide your solution.\n\n"
            f"{sample.get('prompt', sample.get('text', ''))}\n\n"
            "<think>\n"
        )
    
    def _generate_solution(self, prompt: str) -> str:
        """Generate solution for a problem"""
        inputs = self.tokenizer(prompt, return_tensors="pt").to("cuda")
        
        outputs = self.model.generate(
            **inputs,
            max_new_tokens=2048,
            pad_token_id=self.tokenizer.pad_token_id,
            temperature=0.7,
            top_p=0.9,
            do_sample=True,
        )
        
        generated = self.tokenizer.decode(
            outputs[0][inputs["input_ids"].shape[1]:],
            skip_special_tokens=True
        )
        
        return "<think>\n" + generated
    
    def _compute_statistics(self, results: Dict) -> Dict:
        """Compute statistical summary"""
        stats = {
            'format': {
                'mean': np.mean(results['format_scores']),
                'std': np.std(results['format_scores']),
                'median': np.median(results['format_scores']),
            },
            'reasoning': {
                'mean': np.mean(results['reasoning_scores']),
                'std': np.std(results['reasoning_scores']),
                'median': np.median(results['reasoning_scores']),
            },
            'code_quality': {
                'mean': np.mean(results['code_quality_scores']),
                'std': np.std(results['code_quality_scores']),
                'median': np.median(results['code_quality_scores']),
            },
            'correctness': {
                'mean': np.mean(results['correctness_scores']),
                'std': np.std(results['correctness_scores']),
                'median': np.median(results['correctness_scores']),
            },
            'pass_rate': results['all_tests_passed'] / results['total_evaluated'],
            'compilation_fail_rate': results['compilation_failures'] / results['total_evaluated'],
            'total_evaluated': results['total_evaluated'],
        }
        
        return stats
    
    def _save_benchmark_results(self, stats: Dict):
        """Save benchmark results to file"""
        os.makedirs(self.config.benchmark_dir, exist_ok=True)
        
        output_path = os.path.join(
            self.config.benchmark_dir,
            "benchmark_results.json"
        )
        
        with open(output_path, 'w') as f:
            json.dump(stats, f, indent=2)
        
        print(f"\n✓ Results saved to: {output_path}")
    
    def _print_benchmark_summary(self, stats: Dict):
        """Print benchmark summary"""
        print("\n" + "="*50)
        print("BENCHMARK SUMMARY")
        print("="*50)
        
        print(f"\n📊 Evaluated: {stats['total_evaluated']} samples")
        
        print(f"\n✅ Pass Rate: {stats['pass_rate']:.2%}")
        print(f"❌ Compilation Fail Rate: {stats['compilation_fail_rate']:.2%}")
        
        print(f"\n📝 Format Score: {stats['format']['mean']:.3f} ± {stats['format']['std']:.3f}")
        print(f"🧠 Reasoning Score: {stats['reasoning']['mean']:.3f} ± {stats['reasoning']['std']:.3f}")
        print(f"💻 Code Quality: {stats['code_quality']['mean']:.3f} ± {stats['code_quality']['std']:.3f}")
        print(f"✓ Correctness: {stats['correctness']['mean']:.3f} ± {stats['correctness']['std']:.3f}")

# ==========================================
# STEP 4: INFERENCE-TIME TRAINING
# ==========================================

class InferenceTimeTraining:
    """
    Inference-time training via context distillation
    
    During inference, we can:
    1. Generate multiple reasoning paths
    2. Select the best path based on self-consistency
    3. Use the best path to improve future generations
    """
    
    def __init__(self, model, tokenizer, config: PipelineConfig):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
    
    def generate_with_self_consistency(
        self,
        prompt: str,
        num_samples: int = 5,
        temperature: float = 0.8
    ) -> Dict:
        """
        Generate multiple solutions and select via self-consistency
        
        Returns:
        - Best solution
        - Confidence score
        - All solutions
        """
        print("\n" + "="*50)
        print("STEP 4: Inference-Time Training (Self-Consistency)")
        print("="*50)
        
        solutions = []
        
        # Generate multiple solutions
        for i in range(num_samples):
            inputs = self.tokenizer(prompt, return_tensors="pt").to("cuda")
            
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=2048,
                pad_token_id=self.tokenizer.pad_token_id,
                temperature=temperature,
                top_p=0.95,
                do_sample=True,
            )
            
            generated = self.tokenizer.decode(
                outputs[0][inputs["input_ids"].shape[1]:],
                skip_special_tokens=True
            )
            
            solutions.append("<think>\n" + generated)
            print(f"Generated solution {i+1}/{num_samples}")
        
        # Extract code from all solutions
        code_solutions = []
        for sol in solutions:
            _, code = EnhancedRewardFunctions.extract_code(sol)
            if code:
                code_solutions.append(code)
        
        # Find most common solution (self-consistency)
        if code_solutions:
            # Simple approach: use the most common code
            from collections import Counter
            code_counter = Counter(code_solutions)
            best_code, frequency = code_counter.most_common(1)[0]
            confidence = frequency / len(code_solutions)
            
            # Find the full solution with the best code
            best_solution = None
            for sol in solutions:
                _, code = EnhancedRewardFunctions.extract_code(sol)
                if code == best_code:
                    best_solution = sol
                    break
        else:
            best_solution = solutions[0]
            confidence = 0.0
        
        print(f"\n✓ Self-consistency confidence: {confidence:.2%}")
        
        return {
            'best_solution': best_solution,
            'confidence': confidence,
            'all_solutions': solutions,
            'num_unique_codes': len(set(code_solutions)) if code_solutions else 0
        }
    
    def demonstrate_itt(self, test_problem: Dict):
        """Demonstrate inference-time training on a test problem"""
        prompt = (
            "Think step-by-step inside <think></think> tags, "
            "then provide your solution.\n\n"
            f"{test_problem.get('prompt', test_problem.get('text', ''))}\n\n"
            "<think>\n"
        )
        
        result = self.generate_with_self_consistency(prompt, num_samples=5)
        
        print("\n--- Best Solution (via Self-Consistency) ---")
        print(result['best_solution'][:500] + "...")
        
        print(f"\n📊 Unique solutions generated: {result['num_unique_codes']}")
        
        return result

# ==========================================
# MAIN PIPELINE ORCHESTRATOR
# ==========================================

def main():
    """Execute the complete pipeline"""
    
    print("\n" + "="*70)
    print(" QWEN 3 4B END-TO-END COT TRAINING PIPELINE")
    print("="*70)
    
    # Initialize configuration
    config = PipelineConfig()
    
    # ==========================================
    # STEP 1: SFT
    # ==========================================
    sft_pipeline = SFTCoTPipeline(config)
    sft_pipeline.load_model()
    train_dataset, eval_dataset = sft_pipeline.prepare_sft_dataset()
    sft_stats = sft_pipeline.train_sft(train_dataset, eval_dataset)
    
    # ==========================================
    # STEP 2: GRPO
    # ==========================================
    grpo_pipeline = GRPOPipeline(
        config,
        sft_pipeline.model,
        sft_pipeline.tokenizer
    )
    grpo_dataset = grpo_pipeline.prepare_grpo_dataset()
    grpo_pipeline.train_grpo(grpo_dataset)
    
    # ==========================================
    # STEP 3: BENCHMARKING
    # ==========================================
    benchmark_pipeline = BenchmarkPipeline(
        sft_pipeline.model,
        sft_pipeline.tokenizer,
        config
    )
    
    # Prepare test dataset
    test_dataset = grpo_dataset.select(range(min(100, len(grpo_dataset))))
    benchmark_stats = benchmark_pipeline.run_benchmark(test_dataset, num_samples=50)
    
    # ==========================================
    # STEP 4: INFERENCE-TIME TRAINING DEMO
    # ==========================================
    itt_pipeline = InferenceTimeTraining(
        sft_pipeline.model,
        sft_pipeline.tokenizer,
        config
    )
    
    # Demonstrate on a test problem
    test_problem = grpo_dataset[0]
    itt_result = itt_pipeline.demonstrate_itt(test_problem)
    
    # ==========================================
    # FINAL MODEL SAVE
    # ==========================================
    print("\n" + "="*70)
    print("Saving Final Model")
    print("="*70)
    
    os.makedirs(config.final_model_dir, exist_ok=True)
    sft_pipeline.model.save_pretrained(config.final_model_dir)
    sft_pipeline.tokenizer.save_pretrained(config.final_model_dir)
    
    print(f"✓ Final model saved to: {config.final_model_dir}")
    
    print("\n" + "="*70)
    print("🎉 PIPELINE COMPLETE!")
    print("="*70)
    
    # Print summary
    print("\n📊 TRAINING SUMMARY:")
    print(f"  • SFT samples: {len(train_dataset)}")
    print(f"  • GRPO samples: {len(grpo_dataset)}")
    print(f"  • Final pass rate: {benchmark_stats['pass_rate']:.2%}")
    print(f"  • Avg correctness: {benchmark_stats['correctness']['mean']:.3f}")
    
    return {
        'sft_stats': sft_stats,
        'benchmark_stats': benchmark_stats,
        'itt_result': itt_result
    }

if __name__ == "__main__":
    results = main()
